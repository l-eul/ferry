@echo off
setlocal
cd /d "%~dp0"

echo.
echo ========================================
echo             FERRY STARTUP
echo ========================================
echo.

if not exist package.json (
  echo ERROR: package.json was not found.
  echo Run this file from the extracted Ferry folder.
  pause
  exit /b 1
)

if not exist node_modules\vite\bin\vite.js (
  echo Installing dependencies. This can take a few minutes the first time...
  call npm install
  if errorlevel 1 (
    echo.
    echo npm install failed. Copy the error above and send it to support.
    pause
    exit /b 1
  )
)

if not exist .env (
  copy /y .env.example .env >nul
  echo.
  echo Created .env from .env.example.
  echo Open .env and enter your Telegram API ID and API HASH, then run this file again.
  echo.
  pause
  exit /b 0
)

echo Starting Ferry on http://localhost:8080 ...
echo Close this window to stop the server.
echo.
call npm run dev
pause
