# Ferry — Telegram setup

## 1. Configure Telegram credentials

Copy `.env.example` to `.env` and set:

```env
TELEGRAM_API_ID=your_api_id
TELEGRAM_API_HASH=your_api_hash
```

Keep `TELEGRAM_API_HASH` private. Never commit `.env`.

## 2. Install dependencies

From the project directory:

```powershell
npm install
```

## 3. Start Ferry

```powershell
npm run dev
```

Open the localhost URL printed by Vite (the workspace defaults to port 8080).

## 4. Connect Telegram

1. Enter the Telegram phone number in international format.
2. Enter the code Telegram sends to the account.
3. If the account has 2-step verification, enter its Telegram 2FA password.
4. Ferry stores the resulting Telegram session on the server side, not in browser local storage.

## 5. Use real dialogs

After login, Ferry loads the authenticated account's Telegram groups/channels. No generated catalog is used.

Choose a source, load members, choose a destination, select members, and use **Add selected**. Telegram remains authoritative over what can be enumerated or added; permission/privacy/rate-limit errors are surfaced instead of bypassed.

## Important session security

The Telegram session is equivalent to a long-lived login credential. Use a private `.env`/database environment and never paste a session string into chat or source control.

## Session security

Ferry encrypts stored Telegram session strings at rest. For a production deployment, set a separate `FERRY_SESSION_KEY` and keep it private. If it is not set, Ferry derives the encryption key from `TELEGRAM_API_HASH`. Never share the database directory, `.env`, or session data.
