# Ferry release checklist

## Product promise
- Real Telegram user account authentication.
- Real groups/channels from the authenticated account.
- Real member data only; no generated catalog or fake members.
- Explicit source, destination, member selection.
- Telegram remains authoritative for privacy, permissions, membership and rate limits.

## Security
- Telegram API hash stays server-side.
- Telegram session stays server-side and is encrypted at rest.
- Production should set a dedicated `FERRY_SESSION_KEY`.
- Never log phone codes, 2FA passwords, session strings, API hashes or member data unnecessarily.
- Disconnect deletes the stored Telegram session for the current app user.

## Reliability
- Handle expired/invalid login codes.
- Handle Telegram 2FA.
- Handle private/inaccessible chats.
- Handle missing admin permissions.
- Handle privacy-restricted invitees.
- Handle already-members and deleted users.
- Parse `FLOOD_WAIT_<seconds>` and stop rather than hammering Telegram.
- Never claim success unless Telegram accepted the individual invite.

## UX
- Search source and destination dialogs.
- Prevent source = destination.
- Cap one invite run at 100 selected users for traceable results.
- Show loading/working states.
- Show per-user results and export CSV.
- Keep explanations factual when Telegram refuses an operation.

## Before launch
1. Test with a normal group.
2. Test with a private supergroup where the account is an admin.
3. Test with a group where member enumeration is restricted.
4. Test an invite blocked by recipient privacy settings.
5. Test an already-present member.
6. Test a deleted account.
7. Trigger and verify a Telegram flood wait without retrying automatically.
8. Disconnect and confirm the session is removed.
9. Restart the server and confirm the encrypted session reconnects.
10. Run `npm run typecheck` and `npm run build` on a clean install.

## Public / commercial launch
- Enable real application authentication; never use the shared `dev-user` fallback for a multi-user deployment.
- Use a persistent production database and a dedicated `FERRY_SESSION_KEY`.
- Publish a privacy notice explaining what Telegram data is processed, why, where it is stored, and how users disconnect/delete it.
- Publish terms that accurately describe Telegram/API dependencies and limitations.
- Do not promise bypasses for Telegram privacy, admin, participant visibility, spam or rate limits.
- Include a clear Telegram/third-party disclaimer and do not imply endorsement by Telegram.
- Have a tested support path for expired login codes, disconnected sessions, Telegram flood waits, and revoked/invalid sessions.

## Ferry 1.0 release additions
- Server-side eligibility filtering before members are displayed.
- Eligible count is the operation population, not the raw source population.
- Activity filters: any, 24 hours, 7 days, 30 days where Telegram exposes sufficient status information.
- Automatic exclusion of bots and deleted accounts.
- Automatic exclusion of members already in the destination.
- Automatic exclusion of previously recorded permanent invite failures.
- Member enumeration uses streaming/pagination rather than a fixed 10,000-member cap.
- Add operation rechecks destination membership and records permanent failures to avoid repeat attempts.
- Temporary Telegram rate limits remain retryable; permanent privacy/permission failures are not retried automatically.
