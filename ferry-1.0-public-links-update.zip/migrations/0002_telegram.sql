create table if not exists telegram_accounts (
  user_id text primary key,
  session_string text not null,
  telegram_user_id text,
  username text,
  display_name text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
