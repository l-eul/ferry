create table if not exists telegram_member_results (
  user_id text not null,
  destination_id text not null,
  member_id text not null,
  status text not null,
  reason text,
  updated_at timestamptz not null default now(),
  primary key (user_id, destination_id, member_id)
);
create index if not exists telegram_member_results_lookup
  on telegram_member_results (user_id, destination_id, status);
