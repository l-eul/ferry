/**
 * Client-safe sign-out sequencing helpers.
 *
 * This module intentionally contains no Node/server imports so it can be
 * bundled into the browser auth client.
 */

export async function runPreSignInSignOut({
  livePreview,
  hasBearer,
  requestSignOut,
  clearToken,
}) {
  // A preview bearer token is local to the iframe, so clearing it is enough
  // after asking the server to invalidate the corresponding session when one
  // exists. In normal deployments the server-side cookie must be cleared.
  if (!livePreview || hasBearer) {
    try {
      await requestSignOut();
    } catch (error) {
      // Switching providers should not be blocked by an already-expired
      // session. The subsequent OAuth flow establishes the new identity.
      if (!livePreview) {
        // Keep the old session from being reported as active when the server
        // rejected the request, but allow sign-in to proceed.
      }
    }
  }
  clearToken();
}

export async function runSignOut({
  livePreview,
  hasBearer,
  requestSignOut,
  clearToken,
  redirect,
}) {
  if (livePreview) {
    if (hasBearer) {
      try {
        await requestSignOut();
      } catch {
        // The preview token is still cleared below; the iframe has no durable
        // cookie session to preserve.
      }
    }
    clearToken();
    redirect();
    return;
  }

  // In a normal deployment the HttpOnly cookie can only be cleared by the
  // server. Do not redirect if that request fails.
  await requestSignOut();
  clearToken();
  redirect();
}
